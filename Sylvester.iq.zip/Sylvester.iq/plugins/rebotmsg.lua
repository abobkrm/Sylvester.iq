do 

local function bkr(msg, matches) 

if ( msg.text ) then

  if ( msg.to.type == "user" ) then

     return "مرحبا عزيزي  ♥\n للتحدث مع لمطور \n @pl_pl  \n مطور السورس @pl_pl \n تابع قناه السورس @devpl_pl️ "
  end
   
end 


end 

return { 
  patterns = { 
       "(.*)$"
  }, 
  run = bkr, 
} 

end 

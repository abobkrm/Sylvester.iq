do 

local function bkr(msg, matches) 
 local sudo = 292624490
 local r = get_receiver(msg)
  send_large_msg(r, "اصبر حبي😍هسه اصيحه الك😉😘فديتك😃")
  send_large_msg("user#id"..sudo, " مرحبا عزيزي المطور\n هناك شخض بحاجه اليك  :: \n\n ".."⛔ المعرف : @"..msg.from.username.."\n  الايدي : "..msg.from.id.."\n  اسم المجموعة : "..msg.to.title.."\n ايدي المجموعة : "..msg.from.id..'\n  الوقت : '..os.date(' %T*', os.time())..'\n  التاريخ : '..os.date('!%A, %B %d, %Y*\n', timestamp))
end 

return { 
  patterns = { 
     "^(@pl_pl)$" 
  }, 
  run = bkr, 
} 

end

do 

function run(msg, matches) 
return [[ 
【البوت الذي يعمل على 
 مجموعات السوبر تصل الى 5k】 
【 تم صنعهه من قبل 
╔@pl_pl╗ 
تابع  قناه السورس 
@dev_pl_pl
]] 
end 

return { 
description = "dev", 
usage = "dev", 
patterns = { 
"^(المطور)$", 
}, 
run = run 
} 
end 

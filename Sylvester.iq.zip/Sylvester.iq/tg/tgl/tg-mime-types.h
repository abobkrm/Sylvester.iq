char *tg_mime_by_filename (const char *filename);
char *tg_extension_by_mime (const char *mime_type);

